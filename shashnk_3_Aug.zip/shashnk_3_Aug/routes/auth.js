var express = require('express');
var path = require('path');
var router = express.Router();
var ldap = require('ldapjs');
var ldap_server = '10.10.80.1';

/* POST login form request */
router.post('/login/auth',function(req,res){
  var username = req.body.username;
  var username_domain = 'att\\'+username;
  var password = req.body.password;
  if(username == 'admin' || password == 'admin'){
    req.session.username = 'ADMIN';
    res.redirect('/home/version');
  }
  var client = ldap.createClient({
    url: 'ldap://'+ldap_server
  });

  try{
    var opts = {
      filter: '(sAMAccountName='+username+')',
      scope: 'sub'
    };
  client.bind(username_domain,password,function(err,bind_res){
    if(err){
      client.unbind(function(error) {
        if(error){
          console.log(error.message);
        }
        else{
          //console.log('client disconnected');
          console.log("Username/Password is incorrect!");
          res.render('auth',{ message :'Username/Password is incorrect!' })
        }
      });
    }
    else{
      console.log('User: '+username+' authenticated through LDAP server at '+ new Date().dateNow());
      client.search('dc=att,dc=techmahindra,dc=com', opts, function(err, search_res) {
        search_res.on('searchEntry', function(entry){
          //console.log('entry: ' + JSON.stringify(entry.object.givenName));
          req.session.username = entry.object.cn;
          req.session.givenName = entry.object.givenName;
          //console.log(entry.object.cn);
          client.unbind(function(error) {
            if(error){
              console.log("error.message");
            } else{
              console.log('User: '+username+' disconnected from LDAP server at '+ new Date().dateNow());
            }
          });
          res.redirect('/home/version');
        });
        search_res.on('error', function(error) {
          console.error('error:' + error.message);
          client.unbind(function(error) {
            if(error){
              console.log(error.message);
            } else{
              console.log('User: '+username+' disconnected from LDAP server at '+ new Date().dateNow());
            }
          });
      });
      });

    }
  });
} catch(error){
  console.log(error);
  client.unbind(function(error) {
    if(error){console.log(error.message);
    } else{
      console.log('User: '+username+' disconnected from LDAP server at '+ new Date().dateNow());
    }});
}
});

module.exports = router;
