var express = require('express');
var path = require('path');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  //console.log(path.join(__dirname, '../', 'views/auth.html'));
  //res.sendFile(path.join(__dirname, '../', 'views/auth.html'));
  //res.render('maintenance',{ message : ''});
  res.render('auth',{ message : ''});
});

router.get('/logout', function(req, res, next) {
  req.session.destroy();
  res.redirect('/');
});


module.exports = router;
