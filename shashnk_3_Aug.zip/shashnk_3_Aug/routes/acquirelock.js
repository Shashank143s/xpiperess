var express = require('express');
var router = express.Router();
var docuType = require('../public/models/docTypeModel');

router.post('/acquirelock',function(req,res,next){
  //var updDoc = new docuType();
  docuType.findById(req.session.currDoc, function (err, doc) {
    if(doc.lockFlag == 'N' || doc.lockFlag == null){
    doc.lockFlag = 'Y';
    doc.lockedBy = req.session.username;
    doc.lockTS = new Date().prettyDate();
    doc.save((err)=>{
      if(err)
      console.log(err);
      else{
      var message = 'Check-Out in progress by '+doc.lockedBy+'. Check-Out initiated on '+doc.lockTS+'.';
      res.json({ lockmsg : message  , display:'N' , btnCCO: 'Y'});
    }
    });
  }
    else{
        res.json( { message : "Lock already acquired by "+ doc.lockedBy , display: 'N'});
    }
  });
});
//Route for ajax requests
router.get('/checklockval',function(req,res,next){
  docuType.findById(req.session.currDoc, function (err, doc) {
    if(err){
      console.log(err.stack);
    }
    var preVer = '';
    // if(doc.length == 0 || doc.length == 1){
    //   preVer = 'N';
    // }
    if(doc != null){
    if(req.session.username == doc.lockedBy){
      if(doc.lockFlag == 'Y'){
        res.json({btncheckout : 'N' , lockmsg : 'Check-Out in progress by '+doc.lockedBy+'. Check-Out initiated on '+doc.lockTS+'.'});
      }
      else{
        res.json({ btnCCO : 'N' });
      }
    }
    else{
      if(doc.lockFlag == 'Y'){
        res.json({ lockval:'Y' , lockmsg : 'Check-Out in progress by '+doc.lockedBy+'. Check-Out initiated on '+doc.lockTS+'.'});
      }
      else{
        res.json({ btnCCO : 'N' });
      }
    }
  }
  else{
    res.redirect('/');
  }
  });
});

router.post('/checklockval',function(req,res,next){
  docuType.findById(req.session.currDoc, function (err, doc) {
    if(err){
      console.log(err.stack);
    }
    if(req.session.username == doc.lockedBy){
      doc.lockFlag = 'N';
      doc.save((err)=>{
        if(err)
          console.log(err);
        else{
          res.json({ lockval : 'N' });
        }

      });

    }
    else {
      if(doc.lockFlag == 'Y'){
        res.json({ lockval : 'Y'});
      }
      else{
        //console.log(1);
        res.json({ lockval : 'N' });
      }
    }
  });
});

router.post('/cancellock',function(req,res,next){
  docuType.findById(req.session.currDoc, function (err, doc) {
    if(req.session.username == doc.lockedBy){
      doc.lockFlag = 'N';
      doc.save((err)=>{
        if(err)
          console.log(err);
        else{
          res.json({ message : 'You have cancelled your Check-Out!', display:'Y' });
        }
      });
    }
  });
});


module.exports = router;
