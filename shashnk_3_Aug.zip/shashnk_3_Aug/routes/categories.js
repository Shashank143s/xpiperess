var express = require('express');
var path = require('path');
var opusModel = require('../public/javascripts/uploadModel');
var version = require('../public/models/versionDocModel');
var docType = require('../public/models/docTypeModel');
var artifactType = require('../public/models/artifactTypeModel');
var artifactDoc = require('../public/models/artifactDocModel');
var router = express.Router();

/* GET categories and search. */
router.get('/home/:pagename',function(req,res){
	if(req.session.username == undefined)
		res.render('unauth',{ message : 'Unauthorized Access Detected' , error : {status : '401',  stack : 'Please login as this is not \nthe authorized way to access the tool'}});
	else{
		req.session.currPath = '/';
		if(req.params.pagename == 'version'){
			docType.find({parent : req.session.currPath },function(err,docs){
				res.render('homepage',{ docs : docs, userid : req.session.givenName, createfolder : 'version', filehref : 'doc', docver : 'ravcs_active', proart : 'ravcs_inactive', checkoutheader:''  });
			});
		}
		else if(req.params.pagename == 'artifact'){
			artifactType.find({},function(err,docs){
				res.render('homepage',{ docs : docs, userid : req.session.givenName, createfolder : 'artifact', filehref : 'art', docver : 'ravcs_inactive', proart : 'ravcs_active', checkoutheader:'style=display:none;' });
			});
		}
	}
});

// router.get('/doc/*',(req,res)=>{
// 	console.log(req.url);
// });
router.get('/doc/*',(req,res)=>{
	var sessionString = req.url;
	var a = sessionString.split('/');
	for(var i=0; i<a.length; i++){
		a[i]=a[i+2];
	}
	a.length= a.length-2;
	sessionString ='/'+a.join('/');
	req.session.currPath = sessionString;
	docType.find({ parent : req.session.currPath },function(err,docs){
		res.render('homepage',{ docs : docs, userid : req.session.givenName, createfolder : 'version', filehref : 'doc', docver : 'ravcs_active', proart : 'ravcs_inactive', checkoutheader:''  });
	});
});

router.get('/ver/:docname',function(req,res){
	var preVer = '';
	//console.log(req.url);
	if(req.session.username == undefined)
		res.render('unauth',{ message : 'Unauthorized Access Detected' , error : {status : '401',  stack : 'Please login as this is not \nthe authorized way to access the tool'}});
	else{
		req.session.currDoc = req.session.currDoc;

		version.find({ 'doctype' : req.params.docname },function(err,docs){
			if(docs.length == 0){
				res.render('versions',{ docs : docs, userid: req.session.givenName, latestVer: 0, previousVer : 'display:none;', currDoc : req.session.currDoc, btnCI: 'display:block;', btnco : 'display:none;' , btnCCO : 'display:none;' });
				//res.json({ btnCO : 'N' , btnCCO : 'N'});
			}
			else{

				if(docs.length == 1){
					preVer = 'display:none;';
				}
				else{
					preVer = 'display:block;';
				}
				res.render('versions',{ docs : docs, userid: req.session.givenName, latestVer: 1, previousVer : preVer, currDoc : req.session.currDoc, btnCI: 'display:none;', btnco : '' , btnCCO : ''  });

		}
	});
	}
});

router.get('/art/:docname',function(req,res){
	if(req.session.username == undefined)
		res.render('unauth',{ message : 'Unauthorized Access Detected' , error : {status : '401',  stack : 'Please login as this is not \nthe authorized way to access the tool'}});
	else{
		req.session.currDoc = req.params.docname;
		artifactDoc.find({ 'doctype' : req.params.docname },function(err,docs){
				res.render('artifacts',{ docs : docs, userid: req.session.givenName, currDoc : req.session.currDoc, errmsg:''});
	});
	}
});

router.post('/subfolder/value',function(req,res){
	console.log(req.body.id);
	docType.findById(req.body.id, function(err,doc){
		if(err){
			console.log(err);
		}
		if(doc.subFolder == 'N'){
			console.log(doc.subFolder);
			res.json({ sb : doc.subFolder });
		}
		else if(doc.subFolder == 'Y')
			res.json({ sb : doc.subFolder });
	});
});

router.get('/doc/:docname/preVersions',function(req,res){
	if(req.session.username == undefined)
		res.render('unauth',{ message : 'Unauthorized Access Detected' , error : {status : '401',  stack : 'Please login as this is not \nthe authorized way to access the tool'}});
	else{
		version.find({ 'doctype' : req.session.currDoc },function(err,docs){
			if(docs.length == 0){
				res.render('preVersions',{ docs : docs, userid: req.session.givenName, currDoc : req.session.currDoc });
			}
			else
				res.render('preVersions',{ docs : docs, userid: req.session.givenName, currDoc : req.session.currDoc});
		});
	}
});

module.exports = router;
