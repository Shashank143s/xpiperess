var mongoose = require('mongoose');
var db = mongoose.connection;

// create a schema
var artifact = mongoose.Schema({
    _id : String,
    doctype : String,
    lastModified : String,
    lastModifiedBy : String
},{ collection: 'arifacts' });

// the schema is useless so far
// we need to create a model using it
// make this available to our users in our Node applications
module.exports =  db.model('artiType', artifact);
