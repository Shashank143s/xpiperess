var mongoose = require('mongoose');
var db = mongoose.connection;

// create a schema
var homepage = mongoose.Schema({
    _id : String,
    doctype : String,
    createdOn : String,
    createdBy : String,
    parent : String,
    subFolder : String,
    leafFolder : String,
    lockFlag : String,
    lockedBy : String,
    lockTS: String
},{ collection: 'documents' });

// the schema is useless so far
// we need to create a model using it
// make this available to our users in our Node applications
module.exports =  db.model('docuType', homepage);
