var mongoose = require('mongoose');
var db = mongoose.connection;

// create a schema
var versionpage = mongoose.Schema({
    _id : String,
    doctype : String,
    filename : String,
    uploadedBy : String,
    uploadDate : String,
    versionNumber : String,
    filepath : String,
    deleteLink : String
},{ collection: 'versions' });

// the schema is useless so far
// we need to create a model using it
// make this available to our users in our Node applications
module.exports =  db.model('docType', versionpage);
