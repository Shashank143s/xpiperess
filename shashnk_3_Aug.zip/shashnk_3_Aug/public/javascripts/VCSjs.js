 $(document).ready(function(){

  $("#createVer").click(function(e){
    e.preventDefault();
    var fu = document.getElementById("fupload").value;
    if(fu == ''){
      alert('Empty Fields!!');
    }
    else{
      //raise ajax request here
      $.ajax({
        url: "/document/checklockval",
        type: "POST",
        data: {id : 'ajax request'},
        dataType: "json"
      }).done(function(msg) {
            if(msg.lockval == 'N'){
              $('#VDForm').submit();
            }
            else {
              $('#checkin').css('display','none');
              $('#acquirelock').css('display','none');
              $('#cancelCO').css('display','none');
              }
              if(msg.lockmsg){
                $('#lockmessage').html(msg.lockmsg);
              }
              else{
                $('#lockdiv').css('display','none');
              }
          });
    }
  });

  $("#cancelCO").click(function(e){
    $.ajax({
      url: "/document/cancellock",
      type: "POST",
      data: {id : 'ajax request'},
      dataType: "json"
    }).done(function(msg) {
            alert(msg.message);
            $('#lockdiv').css('display','none');
			$('#checkin').css('display','none');
            if(msg.display == 'Y'){
              $("#acquirelock").css('display','block');
              $("#cancelCO").css('display','none');
              $("#cancelCO").css('display','none');
            }
        });
  });

  $("#acquirelock").click(function(e){
    $.ajax({
      url: "/document/acquirelock",
      type: "POST",
      data: {id : 'ajax request'},
      dataType: "json"
    }).done(function(msg) {
            alert(msg.lockmsg);
            if(msg.lockmsg){
              $('#lockdiv').css('display','block');
              $('#lockmessage').html(msg.lockmsg);
			  $('#checkin').css('display','block');
            }
            if(msg.display == 'N'){
              $("#acquirelock").css('display','none');
              $("#cancelCO").css('display','block');

            }
        });
  });

  /*********** AJAX calls to be made on initial page load for buttons visibility*******************/
  /*
  1.Upload New Version/Check-In button - if lock acquired by some other person then do not show
  2.Check-Out button - if lock acquired already by anyone do not show
  3.Cancel Check-Out Button - if lock acquired by some other person then do not show
  */
  $.ajax({
    url: "/document/checklockval",
    type: "GET",
    dataType: "json"
  }).done(function(msg){
      if(msg.btncheckout == 'N'){
        $('#acquirelock').css('display','none');
        $('#checkin').css('display','block');
      }
      if(msg.btnCCO == 'N'){
        $('#cancelCO').css('display','none');
      }
      if(msg.lockval == 'Y'){
        //$('#checkin').css('display','none');
        $('#acquirelock').css('display','none');
        $('#cancelCO').css('display','none');
      }
      if(msg.lockmsg){
        $('#lockmessage').html(msg.lockmsg);
      }
      else{
        $('#lockdiv').css('display','none');
		    //$('#checkin').css('display','none');
      }


  });
});
