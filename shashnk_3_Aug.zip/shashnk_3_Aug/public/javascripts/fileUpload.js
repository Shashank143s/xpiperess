/*******Variable Declaration Section*******/
var express = require('express');
var router = express.Router();
var opusModel = require('./uploadModel');
var docuType = require('../models/docTypeModel');
var artiType = require('../models/artifactTypeModel');
var artiDoc = require('../models/artifactDocModel');
var version = require('../models/versionDocModel');
var fs = require('fs');
var path = require('path');
var multer = require('multer');
var extension = '';
var fname = '';
var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    //Where to store the uploaded files
    cb(null, './public/uploads')
  },
  filename: function (req, file, cb) {
    /*** Code to extract the extension of the file *****/
    var fileextension = file.originalname;
    var filext = fileextension.split('.');
    extension =filext[filext.length -1];
    fname = req.session.currDoc+'_'+ new Date().dateNow();
    /****** End of code for file extension extraction *****/
    //By what file name the uploaded file will be stored
    // console.log(req.path);
      if(req.path === '/VD')
        cb(null,  fname+ '.' + extension)
      else if(req.path === '/AD')
    	  cb(null,  file.originalname)
  }
});
var upload = multer({
					/* dest : './public/uploads' */
					storage:storage });
/**********End of Variable Declaration Section*********/
/********POST Route to serve files uploaded***********/
router.post('/ND/:foldername', upload.array('file',4),function(req,res,next){
  /***** uploading file details on Mongoose******/
  if(req.params.foldername == 'version'){
    var idString;
    console.log(path.join("http:/"+"/localhost:3001/uploads/",req.body.filename+'.'+extension));
    if(req.session.currPath == '/'){
      idString = '/'+req.body.filename;
    }
    else{
      idString = req.session.currPath+'/'+req.body.filename;
    }
    var page = new docuType({
      _id : idString,
      doctype: req.body.filename,
      createdOn: new Date().prettyDate(),
      createdBy: req.session.username,
      parent: req.session.currPath,
      subFolder : 'N',
      leafFolder : 'N',
      lockFlag: 'N',
      lockedBy: 'default',
      lockTS: 'default'
    });
    page.save((err)=>{
      if(err)
      console.log("Document with this name already exists!");
      else
      console.log("Document with name: "+req.body.filename+" created successfully.");//Change this logic to save it in Logs
    })
    /***** uploading file on the server******/
    var nfiles = req.files.length;
    var fileNameArray = [];
    while(nfiles > 0){
      fileNameArray[nfiles-1]= req.files[nfiles -1].filename;
      nfiles--;
    }
    res.redirect('/doc'+req.session.currPath);
  }
  else if(req.params.foldername == 'artifact'){
    console.log(path.join("http:/"+"/localhost:3001/uploads/",req.body.filename+'.'+extension));
    var artifact = new artiType({
      _id : req.body.filename,
      doctype: req.body.filename,
      lastModified: new Date().prettyDate(),
      lastModifiedBy: req.session.username
    });
    artifact.save((err)=>{
      if(err)
      console.log("Document with this name already exists!");
      else
      console.log("Document with name: "+req.body.filename+" created successfully.");//Change this logic to save it in Logs
    })
    /***** uploading file on the server******/
    var nfiles = req.files.length;
    var fileNameArray = [];
    while(nfiles > 0){
      fileNameArray[nfiles-1]= req.files[nfiles -1].filename;
      nfiles--;
    }
    res.redirect('/home/artifact');
  }
});

router.post('/VD', upload.array('file',4),function(req,res,next){
  /***** uploading file version details on Mongoose******/
  version.find({doctype : req.session.currDoc}, (err,doc)=>{
    /****** Logic to get version number automatically********/
  var verDoc = new version({
    _id : fname,
    doctype : req.session.currDoc,
    filename : fname,
    uploadDate : new Date().prettyDate(),
    uploadedBy : req.session.username,
    versionNumber: doc.length+1+'.0',
    filepath : path.join("10.13.68.100:3001/uploads/",fname+'.'+extension),
    deleteLink : '/delete/'+fname
  });
  verDoc.save((err)=>{
    if(err)
    console.log(err);
    else
    console.log("New Version created");//Change this logic to save it in Logs
  });
    });
  /***** uploading file on the server******/
  var nfiles = req.files.length;
	var fileNameArray = [];
	while(nfiles > 0){
		fileNameArray[nfiles-1]= req.files[nfiles -1].filename;
		nfiles--;
	}
	res.redirect('/doc/'+req.session.currDoc);
});

/*** Route POST request to upload Artifacts under a folder in Project Artifacts section***/

router.post('/AD', upload.array('file',4),function(req,res,next){
  /***** uploading file version details on Mongoose******/
  var verDoc = new artiDoc({
    _id : req.files[0].originalname,
    doctype : req.session.currDoc,
    filename : req.files[0].originalname,
    uploadDate : new Date().prettyDate(),
    uploadedBy : req.session.username,
    versionNumber: '.0',
    filepath : path.join("10.13.68.100:3001/uploads/",req.files[0].originalname),
    deleteLink : '/delete/'+req.files[0].originalname
  });
  verDoc.save((err)=>{
    if(err){
    console.log(err.message);
     //res.render('artifacts' , {errmsg : '<div class="alert alert-danger">'+err.message+'</div>', userid: req.session.givenName, currDoc : req.session.currDoc});
  }
    else
    console.log("New Document Uploaded.");//Change this logic to save it in Logs,
  });

  /***** uploading file on the server******/
  var nfiles = req.files.length;
	var fileNameArray = [];
	while(nfiles > 0){
		fileNameArray[nfiles-1]= req.files[nfiles -1].originalname;
		nfiles--;
	}
	res.redirect('/art/'+req.session.currDoc);
});

/**********End of POST Route***********/
module.exports = router;
