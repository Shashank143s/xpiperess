//Import the mongoose module
var mongoose = require('mongoose');

//Set up default mongoose connection
var mongoDB = 'mongodb://localhost:27017/RetailDVCS1test';
mongoose.connect(mongoDB,{
  server: {
    socketOptions: {
      socketTimeoutMS: 0,
      connectionTimeout: 0
    }
  }
});

//Get the default connection
var db = mongoose.connection;
var Schema = mongoose.Schema({
  filename : String,
  filepath : String,
  category : String,
  description : String
},{ collection: 'OPUS_Pages' });

//Bind connection to error event (to get notification of connection errors)
db.on('error', console.error.bind(console, 'MongoDB connection error:'));

module.exports = db.model('opus_page', Schema);
